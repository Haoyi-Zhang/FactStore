# Logical SQL/export evidence payload

`factstore-logical-sql-export.zip` is an ordinary deterministic DEFLATE ZIP.
Every member has a fixed1980 timestamp, regular0644 mode and sorted path. No
symlinks, executables or embedded archives are included. `MANIFEST.json` binds
every other member by SHA256 and byte length. The companion
`publication-file-map.json` maps exact private originals to portable member names;
`publication-receipt.json` binds the ZIP itself and records actual publication
work. All private originals are preserved.

Contents: all frozen inputs, all316 run001 files (including every export,
database, roundtrip and negative-test specimen), exact candidate source preimages,
protocol, environment/source/budget receipts, passing retained-data reread, the
failed25-second optional reread and its original source, and the standalone
archive verifier. No old timing or exhausted budget is rewritten.

The archive's accounting snapshot precedes ZIP construction; the external
publication receipt records that construction/verification charge. This avoids
a circular archive-own-hash/accounting dependency. The timing fields are budget
accounting, not performance results. The old scientific campaign remains closed.

Hash admission (does not extract or execute archive code):

```sh
python -B verify_archive.py --archive factstore-logical-sql-export.zip \
  --expected-sha256 <publication-receipt archive_sha256>
```

Optional full reconstruction, ONLY in fresh private scratch and under an
authorized remaining read-only-check budget:

```sh
python -B verify_archive.py --archive factstore-logical-sql-export.zip \
  --expected-sha256 <publication-receipt archive_sha256> \
  --scratch <absent-private-directory>
```

Full mode checks108 complete exports,12 final engine databases, six final-step
roundtrip databases (one fixed endpoint per case), and six held exports. It does
not freshly reread all54 roundtrip DBs and never reruns the scientific matrix.
The original run did execute54 roundtrips. The first optional full-DB reread
timed out and remains failed. All SQLite bytes are read through SQLite's own
immutable read-only interpreter; no physical-page independence or authentication
is claimed. The verifier imports/executes no code from the archive.

Final DB files are orderly-closed and WAL-free; immutable mode is refused if a
nonempty WAL exists. Read-only reconstruction writes only the new scratch tree,
not the input archive or canonical project. SHA256 provides unkeyed integrity,
not a signature or independent certification. The parent integrates code as an
opt-in example; neither these results nor the ZIP upgrade historical timings.
