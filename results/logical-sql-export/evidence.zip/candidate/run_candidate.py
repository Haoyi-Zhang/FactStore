"""One-process cumulative-budget correctness runner. Never times operations."""
import argparse
import contextlib
import hashlib
import io
import json
import math
import os
from pathlib import Path
import platform
import resource
import signal
import sqlite3
import sys
import time
import traceback
import unittest

HERE = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path = path.resolve()
    if not path.is_relative_to(HERE):
        raise ValueError('all output must remain inside H/worker-a')
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n', encoding='utf-8')


def cpu():
    value = resource.getrusage(resource.RUSAGE_SELF)
    return value.ru_utime + value.ru_stime


def bindings(baseline):
    artifact = baseline / 'artifact'
    paths = list(artifact.rglob('*.py')) + [artifact / 'resource-accounting.json', artifact / 'README.md', artifact / 'FORMAT.md',
        artifact / 'results/native-fanout/reservation.json', artifact / 'results/native-fanout/origin.json',
        artifact / 'results/native-fanout/summary.json', artifact / 'results/raw/resources.json']
    return {p.relative_to(baseline).as_posix(): sha(p) for p in paths}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline', type=Path, required=True)
    args = parser.parse_args()
    baseline = args.baseline.resolve()
    if baseline.is_relative_to(HERE) or not (baseline / 'artifact/resource-accounting.json').is_file():
        raise ValueError('expected read-only canonical baseline')
    policy = json.loads((HERE / 'protocol.json').read_text())
    old = json.loads((baseline / 'artifact/resource-accounting.json').read_text())
    if old['remaining_experiment_allowance_seconds'] != 0 or old['remaining_repair_reproduction_allowance_seconds'] != 0:
        raise ValueError('unexpected historical ledger; no implicit requalification')
    ledger_path = HERE / 'execution-accounting.json'
    ledger = json.loads(ledger_path.read_text()) if ledger_path.exists() else dict(preparation_wall_charge=60, preparation_cpu_charge=30, attempts=[])
    charged_wall = ledger['preparation_wall_charge']
    charged_cpu = ledger['preparation_cpu_charge']
    for a in ledger['attempts']:
        charged_wall += a.get('wall_seconds', a['reserved_wall_seconds'])
        charged_cpu += a.get('cpu_seconds', a['reserved_cpu_seconds'])
    remaining_wall = min(239, 300 - charged_wall - 1)
    remaining_cpu = min(149, 180 - charged_cpu - 1)
    if remaining_wall < 5 or remaining_cpu < 2:
        raise ValueError('cumulative new correctness budget exhausted; never reset')
    index = len(ledger['attempts']) + 1
    out = HERE / f'run-{index:03d}'
    out.mkdir(exist_ok=False)
    attempt = dict(id=index, status='RESERVED_NOT_REFUNDABLE_IF_INCOMPLETE',
        reserved_wall_seconds=remaining_wall, reserved_cpu_seconds=remaining_cpu,
        protocol_sha256=sha(HERE / 'protocol.json'),
        source_bindings={p.name: sha(p) for p in Path(__file__).parent.glob('*.py')})
    ledger['attempts'].append(attempt)
    save(ledger_path, ledger)
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    # Use process lifetime CPU in RLIMIT_CPU, not a fresh zeroed budget.
    cpu_ceiling = max(1, math.floor(cpu() + remaining_cpu))
    resource.setrlimit(resource.RLIMIT_CPU, (cpu_ceiling, cpu_ceiling))
    def expired(signum, frame):
        raise TimeoutError('cumulative correctness wall reservation exceeded')
    signal.signal(signal.SIGALRM, expired)
    signal.alarm(math.floor(remaining_wall))
    started, cpu_started = time.monotonic(), cpu()
    before = bindings(baseline)
    status, error = 'FAIL', None
    try:
        from frozen_inputs import fixed_inputs
        data = fixed_inputs()
        freeze = HERE / 'inputs'
        freeze.mkdir(exist_ok=True)
        raw = (json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':')) + '\n').encode()
        frozen_path = freeze / 'raw-facts-transactions.json'
        if frozen_path.exists():
            if frozen_path.read_bytes() != raw:
                raise ValueError('frozen input changed; preserve original and stop')
        else:
            frozen_path.write_bytes(raw)
        save(freeze / 'manifest.json', dict(sha256=sha(frozen_path), bytes=len(raw), histories=6,
            scales=[16,64,256], widths=[2,8], events_per_history=8, generated_without_producer=True,
            frozen_before_validation=True, performance_repetitions_executed=0))
        data = json.loads(frozen_path.read_bytes())
        with sqlite3.connect(':memory:') as db:
            sqlite_info = dict(version=sqlite3.sqlite_version, source_id=db.execute('SELECT sqlite_source_id()').fetchone()[0], compile_options=[r[0] for r in db.execute('PRAGMA compile_options')])
        mounts = Path('/proc/mounts').read_text().splitlines()
        relevant = [line for line in mounts if str(HERE).startswith(line.split()[1].replace('\\040',' '))]
        save(out / 'environment.json', dict(python=sys.version, platform=platform.platform(), sqlite=sqlite_info,
            private_path=str(HERE), matching_mounts=relevant,
            RLIMIT_AS=list(resource.getrlimit(resource.RLIMIT_AS)), RLIMIT_CPU=list(resource.getrlimit(resource.RLIMIT_CPU)),
            native_ext4_performance_claim=False, power_loss_test=False))
        save(out / 'baseline-before.json', before)
        import test_candidate
        test_root = out / 'test-specimens'; test_root.mkdir()
        test_candidate.TEST_ROOT = test_root
        with (out / 'focused-tests.txt').open('w', encoding='utf-8') as transcript:
            suite = unittest.defaultTestLoader.loadTestsFromModule(test_candidate)
            result = unittest.TextTestRunner(stream=transcript, verbosity=2).run(suite)
        save(out / 'focused-tests.json', dict(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped), success=result.wasSuccessful()))
        if not result.wasSuccessful() or result.skipped:
            raise ValueError('focused test failure; retain complete specimen and transcript')
        from functional_matrix import run
        matrix = out / 'matrix'; matrix.mkdir()
        summary = run(data, matrix, baseline)
        save(out / 'functional-summary.json', summary)
        status = 'PASS'
    except BaseException as exc:
        error = repr(exc)
        (out / 'failure.txt').write_text(traceback.format_exc(), encoding='utf-8')
    finally:
        signal.alarm(0)
        attempt.update(status=status, error=error, wall_seconds=time.monotonic()-started,
            cpu_seconds=cpu()-cpu_started, max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            resource_times_are_budget_accounting_not_scientific_timing=True)
        after = bindings(baseline)
        save(out / 'baseline-after.json', after)
        attempt['baseline_bindings_unchanged'] = before == after
        if before != after:
            attempt['status'] = status = 'FAIL_BASELINE_CHANGED'
        save(out / 'run.json', attempt)
        save(ledger_path, ledger)
    print(json.dumps(dict(status=status, output=str(out), error=error,
        budget_wall_charged=60+sum(a.get('wall_seconds',a['reserved_wall_seconds']) for a in ledger['attempts']),
        budget_cpu_charged=30+sum(a.get('cpu_seconds',a['reserved_cpu_seconds']) for a in ledger['attempts']),
        scientific_timings_collected=False)))
    return 0 if status == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
