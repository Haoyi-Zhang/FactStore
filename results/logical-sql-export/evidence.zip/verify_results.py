"""Bounded read-only rederivation of the retained candidate evidence."""
import hashlib
from contextlib import closing
import json
import math
from pathlib import Path
import resource
import signal
import sqlite3
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'candidate'))
from export_consumer import load, require_endpoint, unique
from sql_export import read_transaction


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    ledger_path = HERE / 'execution-accounting.json'
    ledger = json.loads(ledger_path.read_text())
    wall = 60 + sum(a.get('wall_seconds', a['reserved_wall_seconds']) for a in ledger['attempts'])
    cpu = 30 + sum(a.get('cpu_seconds', a['reserved_cpu_seconds']) for a in ledger['attempts'])
    if wall + 40 > 300 or cpu + 20 > 180:
        raise ValueError('no remaining cumulative budget; do not requalify')
    attempt = dict(id=len(ledger['attempts'])+1, kind='retained-data read-only verification', status='RESERVED',
        reserved_wall_seconds=40, reserved_cpu_seconds=20, verifier_sha256=sha(Path(__file__)),
        scope='All108 frozen exports, all6 held exports,12 final engine databases and6 final roundtrip databases. Prior54 roundtrip executions remain source-bound to run001, not all reread here.')
    ledger['attempts'].append(attempt)
    ledger_path.write_text(json.dumps(ledger, indent=2, sort_keys=True)+'\n')
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    lifetime = resource.getrusage(resource.RUSAGE_SELF)
    before_cpu = lifetime.ru_utime+lifetime.ru_stime
    resource.setrlimit(resource.RLIMIT_CPU, (math.floor(before_cpu+20),math.floor(before_cpu+20)))
    def timeout(signum, frame):
        raise TimeoutError('retained-data verification limit')
    signal.signal(signal.SIGALRM, timeout); signal.alarm(40)
    start = time.monotonic()
    report = dict(status='FAIL')
    try:
        manifest = json.loads((HERE/'inputs/manifest.json').read_text())
        frozen = HERE/'inputs/raw-facts-transactions.json'
        if sha(frozen) != manifest['sha256']:
            raise ValueError('input freeze changed')
        inputs = json.loads(frozen.read_bytes(), object_pairs_hook=unique)
        original = HERE/'run-001'
        run = json.loads((original/'run.json').read_text())
        if run['status']!='PASS' or not run['baseline_bindings_unchanged']:
            raise ValueError('run was not accepted')
        for name, digest in run['source_bindings'].items():
            if sha(HERE/'candidate'/name) != digest:
                raise ValueError('measured candidate source changed: '+name)
        expected = {(h['id'],0):h['initial'] for h in inputs['histories']}
        expected.update({(h['id'],e['step']):e['expected'] for h in inputs['histories'] for e in h['events']})
        rows=[json.loads(line,object_pairs_hook=unique) for line in (original/'matrix/matrix.jsonl').read_text().splitlines()]
        keys=[(r['case'],r['step']) for r in rows]
        if len(keys)!=len(set(keys)) or set(keys)!=set(expected):
            raise ValueError('incomplete or duplicate fixed matrix')
        matrix = original/'matrix'
        before_files={str(p):sha(p) for p in matrix.rglob('*') if p.is_file()}
        def immutable_database(path):
            sidecar=Path(str(path)+'-wal')
            if sidecar.exists() and sidecar.stat().st_size:
                raise ValueError('cannot ignore live WAL in immutable verification')
            with closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro&immutable=1',uri=True)) as db:
                db.execute('BEGIN')
                return read_transaction(db)
        physical=[]
        for row in rows:
            case, step = row['case'], row['step']; value=expected[case,step]
            directory=matrix/case
            for engine, column in [('independent','independent_export_sha256'),('normalized','normalized_export_sha256')]:
                export=directory/engine/f'epoch-{step:02d}.json'
                if sha(export)!=row[column]:raise ValueError('raw export/hash mismatch')
                require_endpoint(load(export),value)
        for history in inputs['histories']:
            directory=matrix/history['id']; final=history['events'][-1]['expected']
            require_endpoint(load(directory/'held-epoch01.json'),history['initial'])
            require_endpoint(immutable_database(directory/'roundtrip-08.sqlite'),final)
            result=dict(case=history['id'],sources=history['sources'],width=history['width'],endpoints=9)
            for engine,db_name in [('independent','logical.sqlite'),('normalized','normalized.sqlite')]:
                root=directory/engine
                require_endpoint(immutable_database(root/db_name),final)
                exports=sum(p.stat().st_size for p in root.glob('epoch-*.json'))
                dbfiles={p.name:p.stat().st_size for p in root.iterdir() if p.is_file() and p.suffix!='.json'}
                result[engine]=dict(database_and_sidecars=dbfiles,database_and_sidecar_bytes=sum(dbfiles.values()),
                    nine_retained_export_bytes=exports,total_engine_bytes=sum(dbfiles.values())+exports)
            physical.append(result)
        if any(sha(Path(p))!=h for p,h in before_files.items()):
            raise ValueError('read-only verification changed retained bytes')
        report=dict(status='PASS',input_sha256=manifest['sha256'],endpoint_pairs=len(rows),
            complete_exports_rechecked=2*len(rows),roundtrip_databases_rechecked=6,final_databases_rechecked=12,
            physical_held_exports_rechecked=6,duplicate_or_missing_matrix_rows=0,
            matrix_bytes_unchanged=True,physical_bytes=physical,
            source='Raw files and complete expected dictionaries, not uploaded summary counts',
            limitation='First optional all-database reread exceeded25s and remains a failure. This narrower reread covers every export and every final case, not all54 roundtrip database files. Per-step WAL/SHM lengths are recorded observations, not reconstructable WAL history after orderly close. Final file sizes above are rederived. No device bytes or speed comparison.')
    except BaseException as error:
        report.update(error=repr(error))
        raise
    finally:
        signal.alarm(0)
        used=resource.getrusage(resource.RUSAGE_SELF)
        attempt.update(status=report['status'],wall_seconds=time.monotonic()-start,
            cpu_seconds=used.ru_utime+used.ru_stime-before_cpu,
            resource_times_are_budget_accounting_not_scientific_timing=True)
        ledger_path.write_text(json.dumps(ledger,indent=2,sort_keys=True)+'\n')
        (HERE/'retained-verification.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='physical_bytes'}))
    return 0


if __name__=='__main__':
    raise SystemExit(main())
