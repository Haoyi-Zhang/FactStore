# Independent logical-SQL/export candidate

This is an implemented ordinary-SQL alternative, not a new timing campaign.
The canonical project, frozen G, historical result bytes and exhausted ledger
were not edited. Parent review/apply remains required.

## What changed substantively

`LogicalSQL.apply` computes affected facts through SQL dependency queries and
lowers source edits, explicit retractions, fact replacements and schema cutover
inside one WAL/FULL transaction. It does not receive a producer-computed delta.
`read_transaction` reads the complete four-relation endpoint in one transaction,
uses LEFT JOINs so orphan edges cannot disappear, and derives the inverse from
actual SQL rows. `export_database` writes that complete endpoint to an ordinary
durably published JSON file, not a cached proposed state.

`export_consumer.py` is a separate stdlib implementation. It imports neither
SQLite, the SQL writer, the old transition model nor the segment parser. It
checks strict types, full record structure, nonempty ordered dependencies,
source-generation/schema closure and the exact inverse. Complete endpoint
comparison is separate: a structurally valid wrong fact payload is deliberately
accepted as closed but rejected against the frozen expected endpoint.

The SQL writer/exporter/consumer/input generator import no producer internals.
Only `functional_matrix.py`'s clearly separated compatibility adapter imports
the old data classes and unchanged SQLiteNormalized writer. Those are not used
to compute the expected oracle. The same frozen transactions and complete raw
expected dictionaries are consumed by both paths. The independent SQL path
computes invalidation; the old normalized path receives its precomputed delta.
This is not equal-computation performance work, and is not timed.

## Actual evidence

`inputs/raw-facts-transactions.json` was frozen before validation:
SHA256 `711e9893486daa9bd8da727e48affb99634f22145466c61b769e7b7d5179945a`.
Six owned histories cover16/64/256 source rows, six facts per source, dependency
widths2/8 and eight updates. These are synthetic database states, not independent
source programs. The duplicate seven-repeat placeholder is never executed.

The first guarded run passed12 focused methods and every fixed functional case:
54 paired complete endpoints,108 independently consumed JSON exports,54 fresh
SQL import/export roundtrips, six physical held-snapshot exports and12 orderly
engine reopens. Raw JSONL, actual exports, databases, negative specimens and
source/protocol identities are retained under `run-001/`. No failed matrix row
was discarded or replaced. The runtime was WSL Python3.12.3/SQLite3.45.1 on
H's `/mnt/c`9p mount; this is not native-ext4 performance evidence.

The old28800-CPU-second allowance remains exhausted. The new correctness ledger
also preserves a failed optional data-only all-database reread that exceeded its
25-second sublimit. That failed reread does not negate or certify the original
guarded run. The final retained-data report explicitly states its narrower
re-reading coverage. Use `execution-accounting.json` for the complete cumulative
correctness charge, not only the passing run's time. All durations are resource
accounting, not scientific latency measurements.

## Integration

`integration.patch` adds the exact tested core bytes under the flat
`artifact/independent_sql_export/` directory, plus a small CLI and this guide.
It edits no old writer, historical tests, budget, result, manuscript or authors.
The separate focused test command is explicit; it is not silently represented
as execution by the old default suite or added to old historical test counts.
Parent must register any retained new dataset/command in the actual admission
consumer and CI before claiming it is delivered current evidence. Retain the
original H source preimages and their hashes rather than rebinding old native
timings to this new export path.

After parent applies, a fresh owned normalized database can be exported with:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B artifact/independent_sql_export/cli.py \
  --database <owned-normalized.sqlite> --output <fresh-private-export.json>
```

Optional `--expected` takes a separate trusted complete state JSON, not a hash,
summary, cached producer state, or a whole history wrapper. The CLI otherwise
claims only a complete structurally valid SQL export, not ground truth.

Focused tests, only under an authorized remaining correctness allowance:

```sh
TMPDIR=<owned-private-scratch> PYTHONDONTWRITEBYTECODE=1 \
  PYTHONPATH=artifact/independent_sql_export \
  python -B -m unittest discover -s artifact/independent_sql_export \
    -p test_candidate.py -v
```

No performance runner/mode is included. Do not invoke the exhausted historical
guarded runner. The existing accepted native-fanout measurements still describe
the old SQLite-N path WITHOUT this export; they must not be relabelled as costs
of SQL-Logical-Export.

## Exact remaining non-goals

* SQLite's interpreter is still trusted; its physical pages are not independently
  parsed. Algorithmic/source independence is not team or human independence.
* DB commit and JSON replacement have no common atomic selector. An interruption
  between them can leave an old export alongside a new DB. Successful quiescent
  export/equality is not the rooted engines' crash-atomic cross-interface contract.
* No raw-device power loss, concurrent writers, authenticated history, long-run
  archive reclamation, analyzer dependency soundness or production deployment.
* No new native-ext4 timing, seven-repeat lifecycle cohort, universal speed/space
  ordering, or independent real-world program population. Original small native
  three-repeat evidence and its limitations remain unchanged.
* File sizes are actual logical lengths including recorded DB/WAL/SHM/export
  files, not block allocation, physical device traffic or write amplification.

Suggested manuscript integration is one separate, untimed candidate paragraph:
ordinary SQL can also expose a complete independently consumed logical export;
the new implementation derives invalidation from SQL dependencies and validates
the same frozen endpoints at three modest scales. Keep the historical timing
comparison's original source/contract boundary, and state the missing common
DB/export selector explicitly. Do not claim this candidate matches all rooted
publication guarantees or establishes a performance advantage.
